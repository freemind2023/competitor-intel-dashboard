import streamlit as st

st.set_page_config(page_title="Competitor Intelligence", page_icon="📊")

st.title("📊 Competitor Intelligence Dashboard")
st.subheader("Welcome to your smart SaaS project!")
st.markdown("This is Day 1 — setup complete.")